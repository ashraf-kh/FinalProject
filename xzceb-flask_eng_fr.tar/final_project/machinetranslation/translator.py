import json
from ibm_watson import LanguageTranslatorV3
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import os
from dotenv import load_dotenv

load_dotenv()
apikey = os.environ['apikey']
url = os.environ['url']
#text_to_translate = os.environ['text_to_translate']
authenticator = IAMAuthenticator(apikey)
language_translator = LanguageTranslatorV3(
    version='2018-05-01',
    authenticator=authenticator
)
language_translator.set_service_url(url)


englishText = input("Please Enter English text to be translated to French: ")
def englishToFrench(englishText):
    #write the code here
    model_id = 'en-fr'
    frenchText = language_translator.translate(
    text=englishText,model_id=model_id).get_result()
    
    print(json.dumps(frenchText, indent=2, ensure_ascii=False))
    return frenchText
englishToFrench(englishText)

frenchText = input("Please Enter French text to be translated to English: ")
def frenchToEnglish(fenchText):
    #write the code here
    model_id = 'fr-en'
    englishText = language_translator.translate(
    text=frenchText,model_id=model_id).get_result()
    
    print(json.dumps(englishText, indent=2, ensure_ascii=False))
    return englishText
frenchToEnglish(frenchText)


    
